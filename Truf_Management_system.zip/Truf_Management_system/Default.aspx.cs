﻿using System;
using System.Web.UI;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // You can add logic here if needed in the future.
        // For now, no specific functionality is required on page load.
    }
}
