﻿using System;
using System.Web.UI;

public partial class BookingPayment : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Text = "";
        }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Booking.aspx");
    }

    protected void btnPayNow_Click(object sender, EventArgs e)
    {
        string paymentMode = rblPaymentMode.SelectedValue;
        string nameOnCard = txtNameOnCard.Text.Trim();
        string cardNumber = txtCardNumber.Text.Trim();
        string expiry = txtExpiry.Text.Trim();

        if (paymentMode == "Card")
        {
            if (string.IsNullOrEmpty(nameOnCard) || string.IsNullOrEmpty(cardNumber) || string.IsNullOrEmpty(expiry))
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Please fill all card details.";
                return;
            }

            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "Card Payment Successful! Thank you for booking.";
        }
        else if (paymentMode == "UPI")
        {
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "UPI Payment Initiated. Please scan the QR and complete the transaction.";
        }
        else if (paymentMode == "NetBanking")
        {
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "Net Banking Payment Successful! Thank you for booking.";
        }
        else
        {
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "Please select a payment mode.";
        }
    }
}
